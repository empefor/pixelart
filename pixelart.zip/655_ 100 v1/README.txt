carrots taken from: https://mcpedl.com/over-programmed/
some textures are from the 1.14 default texture pack (https://www.planetminecraft.com/texture-pack/1-14-default-short-sword-for-1-8-9/) by bamto
Most of the item textures that I made were actually made on my school's chromebook, and since it didn't have a (good) software to make pixel art, I had to use piskelapp for it